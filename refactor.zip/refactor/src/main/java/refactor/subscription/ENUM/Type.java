package refactor.subscription.ENUM;

public enum Type {
    Music,
    Video,
    Podcast
}
