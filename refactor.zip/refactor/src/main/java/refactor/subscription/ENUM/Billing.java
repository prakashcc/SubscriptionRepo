package refactor.subscription.ENUM;

public enum Billing {

    Monthly,
    Quarterly,
    Annual
}
